/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Daniel
 */
import javax.swing.JTextArea;
import java.io.*;  
import java.net.*;


public class SocketClient implements Runnable{
	String dato;
    OutputStream output_salida;
	DataOutputStream data_salida;
	boolean salida=true;

	InputStream input_entrada;
	DataInputStream data_entrada;

	Socket cliente;
	Thread hilotext;
	JTextArea textbox;
	public SocketClient(JTextArea caja){
		this.textbox=caja;
		hilotext=new Thread(this);
		hilotext.start();
		try {	
			cliente = new Socket("127.0.0.1", 3000);  
			output_salida = cliente.getOutputStream();
			data_salida = new DataOutputStream(output_salida);

			input_entrada = cliente.getInputStream();
			data_entrada = new DataInputStream(input_entrada);
 
			dato = data_entrada.readUTF();
	        caja.setText(caja.getText()+dato);
		}
		catch (Exception e) {
			System.err.println("Error: " + e);
		}
	}

	public void Mensaje(String mensajes){
		
		try {	
			data_salida.writeUTF(mensajes+"\n");
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
	}
		
	public void CerrarSesion(){
		
		try {
			data_salida.close();
			data_entrada.close();
		    cliente.close();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
		
	}

	@Override
	public void run() {
		Thread ct= Thread.currentThread();
		if(ct==hilotext){
			try {
		do{	
				dato = data_entrada.readUTF();
				textbox.setText(textbox.getText()+dato);
		        //System.out.println("El cliente recibio: "+dato);
			
		}while(true);
		
       } catch (Exception e) {
				
			}
		}
	
	}
	
 
	
}