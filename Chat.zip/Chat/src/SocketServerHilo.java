/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Daniel
 */
import java.util.ArrayList;
import java.io.*;
import java.net.*;


public class SocketServerHilo implements Runnable {

    String recibido;
    OutputStream output_salida;
	DataOutputStream data_salida;

	InputStream input_entrada;
	DataInputStream data_entrada;

	Socket socket;
	int numerodelhilo;
	
	ArrayList<SocketServerHilo> hermanos;

	public SocketServerHilo(Socket lsocket,int numerodelhilo,ArrayList<SocketServerHilo> hermanos){
		try{
			this.numerodelhilo=numerodelhilo;
			this.hermanos=hermanos;
			socket = lsocket;			
		}
		catch (Exception excepcion) {
			System.out.println(excepcion);
		}		
	}

	public void run() {	

		try{			
			output_salida = socket.getOutputStream();
			data_salida = new DataOutputStream(output_salida);

			input_entrada = socket.getInputStream();
			data_entrada = new DataInputStream(input_entrada);

			data_salida.writeUTF("Bienvenido al servidor\n");

			do{
				recibido = data_entrada.readUTF();	
				
				int tama=hermanos.size();
				for (int i = 0; i < tama; i++) {
					hermanos.get(i).data_salida.writeUTF("Cliente "+numerodelhilo+": "+recibido);
					 
				}
				
			}while(!recibido.equals("Adios"));
		}
		catch (IOException excepcion) {
			System.out.println("Ha salido del servidor "+numerodelhilo);
		//	System.out.println(excepcion.getMessage());
		}		
		
		try{
			data_salida.close();
			data_entrada.close();
			socket.close();			
		}
		catch (IOException excepcion) {
			System.out.println(excepcion);
		}			
	}
}