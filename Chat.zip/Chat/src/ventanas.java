/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Daniel
 */
import java.awt.*;   
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import javax.swing.*;


public class ventanas extends JFrame  implements Runnable{
	JTextArea TextBox=new JTextArea();
	JTextField info=new JTextField(20);
	JButton boton=new JButton();
	String infoserver="Desconectado";
	
	
	JScrollPane barra = new JScrollPane();
	
	String dato;
    OutputStream output_salida;
	DataOutputStream data_salida;
	boolean salida=true;

	InputStream input_entrada;
	DataInputStream data_entrada;

	Socket cliente;
	Thread hilocaja;
	
	
	public ventanas() {
		
            
            TextBox.setBackground(Color.BLACK);
            TextBox.setForeground(Color.blue);
		setSize(500,500);
		setLocation(200,200);
		
		Server();
		
		setVisible(true);	
		
		barra.setViewportView(TextBox);
		try {	
			
			cliente = new Socket("127.0.0.1", 3000);  
			output_salida = cliente.getOutputStream();
			data_salida = new DataOutputStream(output_salida);

			input_entrada = cliente.getInputStream();
			data_entrada = new DataInputStream(input_entrada);
 
			dato = data_entrada.readUTF();
	        TextBox.setText(TextBox.getText()+dato);
		}
		catch (Exception e) {
			System.err.println("Error: " + e);
		}
		
		hilocaja=new Thread(this);
		hilocaja.start();
		
	}


	public void Server() { 
		try {
			
		} catch (Exception e) {
			
		}  
		
		this.setLayout(new GridLayout(1, 1, 1, 1));
		JPanel Panel_servidor=new JPanel();
		Panel_servidor.setLayout(new BorderLayout());
				
		JPanel Panel_cliente=new JPanel();
		Panel_cliente.setLayout(new BorderLayout());
		JPanel panelcentro=new JPanel();
		panelcentro.setLayout(new FlowLayout());
		this.info.setText("");
		this.boton.setText("Enviar");
		panelcentro.add(this.info);
		panelcentro.add(this.boton);
		boton.addActionListener(
				new ActionListener(){
					public void actionPerformed(ActionEvent evento){
					 try {
						data_salida.writeUTF(info.getText()+"\n");
                                                info.setText("");
					} catch (IOException e) {
						
						e.printStackTrace();
					}
							
					}	
				}
			);
		
		
		
        Panel_cliente.add(panelcentro, BorderLayout.CENTER);
		
		
		
		Panel_servidor.add(barra, BorderLayout.CENTER);
		Panel_servidor.add(Panel_cliente, BorderLayout.SOUTH);
		this.add(Panel_servidor);
		
			}
	public void Cliente() {
		this.setLayout(new GridLayout(1, 1, 1, 1));
				
	}
	
public void CerrarSesion(){
		
		try {
			data_salida.close();
			data_entrada.close();
		    cliente.close();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
		
	}
@Override
public void run() {
	Thread ct= Thread.currentThread();
	if(ct==hilocaja){
		try {
			
			do{
			dato = data_entrada.readUTF();
			TextBox.setText(TextBox.getText()+dato);
	    
	        
	}while(true);
		} catch (Exception e) {
			TextBox.setText(TextBox.getText()+"Error \n ");
		}
	
	}

}		

	public static void main(String[] args) {
		ventanas obj= new ventanas();
	}
	
}
