/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Daniel
 */
import java.util.ArrayList;
import java.net.*;
import java.io.*;

public class SocketServer {
	
    public static void main(String[] args) throws IOException {    
			ArrayList<SocketServerHilo> clientes=new ArrayList<>();
                            int numero_cliente=0;
		try {
			ServerSocket server = new ServerSocket(3000);			
			do
			{
							
				System.out.println("Esperando la conexion de un nuevo cliente");							
				Socket socketConectado = server.accept();
                numero_cliente++;
                SocketServerHilo hilocliente= new SocketServerHilo(socketConectado,numero_cliente,clientes);
                clientes.add(hilocliente);
                Runnable nuevoSocket=hilocliente;
              
				Thread hiloSocket = new Thread(nuevoSocket);
				
				hiloSocket.start();
				
				System.out.println("Nuevo cliente recibido");								
			}while(true);
			
		}
		catch (IOException excepcion) {			
			System.out.println(excepcion);
		}

    }
}
